<?php
/**
 * Created by PhpStorm.
 * User: abderrahimelimame
 * Date: 8/7/16
 * Time: 00:21
 */

?>

</div>
</main>
</div>
</body>

<footer class="mdl-mega-footer">
    <!--  Scripts-->
    <script src="material/material.js"></script>
    <script language="JavaScript" type="text/javascript">
        function checkDelete() {
            return confirm('Are you sure?');
        }
    </script>

</footer>
</html>